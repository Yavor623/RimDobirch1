﻿namespace RIMDobrich1
{
    partial class SignInForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            usernameTextBox = new TextBox();
            passwordTextBox = new TextBox();
            usernameLabel = new Label();
            passwordLabel = new Label();
            logInButton = new Button();
            label1 = new Label();
            passwordCheckBox = new CheckBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // usernameTextBox
            // 
            usernameTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            usernameTextBox.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            usernameTextBox.Location = new Point(3, 70);
            usernameTextBox.MaxLength = 40;
            usernameTextBox.Multiline = true;
            usernameTextBox.Name = "usernameTextBox";
            usernameTextBox.Size = new Size(661, 65);
            usernameTextBox.TabIndex = 0;
            usernameTextBox.KeyDown += usernameTextBox_KeyDown;
            // 
            // passwordTextBox
            // 
            passwordTextBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            passwordTextBox.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            passwordTextBox.Location = new Point(3, 208);
            passwordTextBox.MaxLength = 40;
            passwordTextBox.Multiline = true;
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.PasswordChar = '*';
            passwordTextBox.Size = new Size(661, 65);
            passwordTextBox.TabIndex = 1;
            passwordTextBox.KeyDown += usernameTextBox_KeyDown;
            // 
            // usernameLabel
            // 
            usernameLabel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            usernameLabel.AutoSize = true;
            usernameLabel.Font = new Font("Cambria", 16F, FontStyle.Regular, GraphicsUnit.Point);
            usernameLabel.Location = new Point(3, 0);
            usernameLabel.Name = "usernameLabel";
            usernameLabel.Size = new Size(661, 67);
            usernameLabel.TabIndex = 2;
            usernameLabel.Text = "Потребителско име:";
            // 
            // passwordLabel
            // 
            passwordLabel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            passwordLabel.AutoSize = true;
            passwordLabel.Font = new Font("Cambria", 16F, FontStyle.Regular, GraphicsUnit.Point);
            passwordLabel.Location = new Point(3, 138);
            passwordLabel.Name = "passwordLabel";
            passwordLabel.Size = new Size(661, 67);
            passwordLabel.TabIndex = 3;
            passwordLabel.Text = "Парола:";
            // 
            // logInButton
            // 
            logInButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            logInButton.BackColor = Color.NavajoWhite;
            logInButton.FlatAppearance.BorderSize = 0;
            logInButton.FlatStyle = FlatStyle.Flat;
            logInButton.Font = new Font("Cambria", 16F, FontStyle.Regular, GraphicsUnit.Point);
            logInButton.Location = new Point(3, 372);
            logInButton.Name = "logInButton";
            logInButton.Size = new Size(661, 90);
            logInButton.TabIndex = 4;
            logInButton.Text = "Влизане";
            logInButton.UseVisualStyleBackColor = false;
            logInButton.Click += logInButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(327, 5);
            label1.Name = "label1";
            label1.Size = new Size(0, 20);
            label1.TabIndex = 18;
            // 
            // passwordCheckBox
            // 
            passwordCheckBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            passwordCheckBox.AutoSize = true;
            passwordCheckBox.Font = new Font("Cambria", 16F, FontStyle.Regular, GraphicsUnit.Point);
            passwordCheckBox.Location = new Point(3, 279);
            passwordCheckBox.Name = "passwordCheckBox";
            passwordCheckBox.Size = new Size(661, 87);
            passwordCheckBox.TabIndex = 19;
            passwordCheckBox.Text = "Покажи парола";
            passwordCheckBox.UseVisualStyleBackColor = true;
            passwordCheckBox.CheckedChanged += passwordCheckBox_CheckedChanged;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(passwordCheckBox, 0, 4);
            tableLayoutPanel1.Controls.Add(logInButton, 0, 5);
            tableLayoutPanel1.Controls.Add(usernameLabel, 0, 0);
            tableLayoutPanel1.Controls.Add(usernameTextBox, 0, 1);
            tableLayoutPanel1.Controls.Add(passwordLabel, 0, 2);
            tableLayoutPanel1.Controls.Add(passwordTextBox, 0, 3);
            tableLayoutPanel1.Location = new Point(199, 153);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 6;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.573267F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.2979088F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.573267F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.2979088F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20.1288223F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20.1288223F));
            tableLayoutPanel1.Size = new Size(667, 465);
            tableLayoutPanel1.TabIndex = 20;
            // 
            // SignInForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1013, 753);
            Controls.Add(label1);
            Controls.Add(tableLayoutPanel1);
            MaximizeBox = false;
            MinimumSize = new Size(1031, 800);
            Name = "SignInForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Вход";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox usernameTextBox;
        private TextBox passwordTextBox;
        private Label usernameLabel;
        private Label passwordLabel;
        private Button logInButton;
        private Label label1;
        private CheckBox passwordCheckBox;
        private TableLayoutPanel tableLayoutPanel1;
    }
}