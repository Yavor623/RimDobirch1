﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace RIMDobrich1
{
    public partial class SignInForm : Form
    {
        string directorPassword = "";
        int museumName;
        int privileges;
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataAdapter DtA = new MySqlDataAdapter();
        MySqlDataReader sqlRd;
        DataSet DS = new DataSet();

        String server = "127.0.0.1";
        String username = "root";
        String password = "";
        String database = "rim_dobrich";
        public SignInForm()
        {
            InitializeComponent();
        }

        private void logInButton_Click(object sender, EventArgs e)
        {
            string userPassword = "";
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database}";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = $"SELECT password,privilegeId,nameofmuseum_id FROM Users WHERE username = '{usernameTextBox.Text}'";

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                userPassword = reader.GetString("password");
                privileges = reader.GetInt32("privilegeId");
                museumName = reader.GetInt32("nameofmuseum_id");
            }

            sqlConn.Close();


            if (userPassword == passwordTextBox.Text)
            {
                if (privileges == 1)
                {
                    directorPassword = passwordTextBox.Text;
                    MessageBox.Show("Успешно влизане");
                    SignInForm signInForm = new SignInForm();
                    DirectorMenu directorMenu = new DirectorMenu(directorPassword);
                    directorMenu.Show();
                    this.Hide();
                    signInForm.Close();
                }
                else
                {
                    MessageBox.Show("Успешно влизане");
                    SignInForm signInForm1 = new SignInForm();
                    Menu menu = new Menu(museumName);
                    menu.Show();
                    this.Hide();
                    signInForm1.Close();
                }

            }
        }

        private void passwordCheckBox_CheckedChanged(object sender, EventArgs e)
        {

            if (passwordCheckBox.Checked)
            {
                passwordTextBox.PasswordChar = '\0';
            }
            else
            {
                passwordTextBox.PasswordChar = '*';
            }
        }

        private void usernameTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }

        }
    }
}
