﻿namespace RIMDobrich1
{
    partial class CollectionsMuseum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CollectionsMuseum));
            updatebtn = new Button();
            deletebtn = new Button();
            addNewbtn = new Button();
            materialDataGrid = new DataGridView();
            collectionNameTxt = new TextBox();
            resetBtn = new Button();
            collectionIdTxt = new TextBox();
            menubtn = new Button();
            sectionsbtn = new Button();
            typesbtn = new Button();
            shapesbtn = new Button();
            materialsbtn = new Button();
            quieriesbtn = new Button();
            artefactsbtn = new Button();
            museumsbtn = new Button();
            collectionsbtn = new Button();
            assesmentProtocolbtn = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)materialDataGrid).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // updatebtn
            // 
            updatebtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(updatebtn, 3);
            updatebtn.Cursor = Cursors.Hand;
            updatebtn.Dock = DockStyle.Bottom;
            updatebtn.FlatStyle = FlatStyle.Flat;
            updatebtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            updatebtn.Location = new Point(3, 593);
            updatebtn.Name = "updatebtn";
            updatebtn.Size = new Size(552, 75);
            updatebtn.TabIndex = 47;
            updatebtn.Text = "Обнови";
            updatebtn.UseVisualStyleBackColor = false;
            updatebtn.Click += updatebtn_Click;
            // 
            // deletebtn
            // 
            deletebtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(deletebtn, 3);
            deletebtn.Cursor = Cursors.Hand;
            deletebtn.Dock = DockStyle.Bottom;
            deletebtn.FlatStyle = FlatStyle.Flat;
            deletebtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            deletebtn.Location = new Point(3, 742);
            deletebtn.Name = "deletebtn";
            deletebtn.Size = new Size(552, 75);
            deletebtn.TabIndex = 46;
            deletebtn.Text = "Премахни";
            deletebtn.UseVisualStyleBackColor = false;
            deletebtn.Click += deletebtn_Click;
            // 
            // addNewbtn
            // 
            addNewbtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(addNewbtn, 3);
            addNewbtn.Cursor = Cursors.Hand;
            addNewbtn.Dock = DockStyle.Bottom;
            addNewbtn.FlatStyle = FlatStyle.Flat;
            addNewbtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            addNewbtn.Location = new Point(3, 444);
            addNewbtn.Name = "addNewbtn";
            addNewbtn.Size = new Size(552, 75);
            addNewbtn.TabIndex = 45;
            addNewbtn.Text = "Добави";
            addNewbtn.UseVisualStyleBackColor = false;
            addNewbtn.Click += addNewbtn_Click;
            // 
            // materialDataGrid
            // 
            materialDataGrid.AccessibleRole = AccessibleRole.None;
            materialDataGrid.AllowUserToAddRows = false;
            materialDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            materialDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            materialDataGrid.BackgroundColor = Color.Tan;
            materialDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tableLayoutPanel1.SetColumnSpan(materialDataGrid, 7);
            materialDataGrid.Cursor = Cursors.PanNW;
            materialDataGrid.Location = new Point(561, 78);
            materialDataGrid.MultiSelect = false;
            materialDataGrid.Name = "materialDataGrid";
            materialDataGrid.ReadOnly = true;
            materialDataGrid.RowHeadersWidth = 51;
            tableLayoutPanel1.SetRowSpan(materialDataGrid, 6);
            materialDataGrid.RowTemplate.Height = 29;
            materialDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            materialDataGrid.Size = new Size(1269, 894);
            materialDataGrid.TabIndex = 44;
            materialDataGrid.CellClick += materialDataGrid_CellClick;
            // 
            // collectionNameTxt
            // 
            tableLayoutPanel1.SetColumnSpan(collectionNameTxt, 3);
            collectionNameTxt.Dock = DockStyle.Bottom;
            collectionNameTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            collectionNameTxt.Location = new Point(3, 310);
            collectionNameTxt.Multiline = true;
            collectionNameTxt.Name = "collectionNameTxt";
            collectionNameTxt.PlaceholderText = "Име на сбирка";
            collectionNameTxt.Size = new Size(552, 60);
            collectionNameTxt.TabIndex = 43;
            collectionNameTxt.KeyDown += collectionNameTxt_KeyDown;
            // 
            // resetBtn
            // 
            resetBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(resetBtn, 3);
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.Dock = DockStyle.Bottom;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(3, 897);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(552, 75);
            resetBtn.TabIndex = 53;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // collectionIdTxt
            // 
            tableLayoutPanel1.SetColumnSpan(collectionIdTxt, 3);
            collectionIdTxt.Dock = DockStyle.Bottom;
            collectionIdTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            collectionIdTxt.Location = new Point(3, 161);
            collectionIdTxt.Multiline = true;
            collectionIdTxt.Name = "collectionIdTxt";
            collectionIdTxt.PlaceholderText = "Индекс";
            collectionIdTxt.Size = new Size(552, 60);
            collectionIdTxt.TabIndex = 42;
            collectionIdTxt.KeyDown += collectionIdTxt_KeyDown;
            // 
            // menubtn
            // 
            menubtn.BackColor = Color.NavajoWhite;
            menubtn.Cursor = Cursors.Hand;
            menubtn.FlatAppearance.BorderSize = 0;
            menubtn.FlatStyle = FlatStyle.Flat;
            menubtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            menubtn.Location = new Point(3, 3);
            menubtn.Name = "menubtn";
            menubtn.Size = new Size(162, 35);
            menubtn.TabIndex = 0;
            menubtn.Text = "Меню";
            menubtn.UseVisualStyleBackColor = false;
            menubtn.Click += menubtn_Click;
            // 
            // sectionsbtn
            // 
            sectionsbtn.BackColor = Color.NavajoWhite;
            sectionsbtn.Cursor = Cursors.Hand;
            sectionsbtn.FlatAppearance.BorderSize = 0;
            sectionsbtn.FlatStyle = FlatStyle.Flat;
            sectionsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsbtn.Location = new Point(375, 3);
            sectionsbtn.Name = "sectionsbtn";
            sectionsbtn.Size = new Size(162, 35);
            sectionsbtn.TabIndex = 2;
            sectionsbtn.Text = "Отдели";
            sectionsbtn.UseVisualStyleBackColor = false;
            sectionsbtn.Click += sectionsbtn_Click;
            // 
            // typesbtn
            // 
            typesbtn.BackColor = Color.NavajoWhite;
            typesbtn.Cursor = Cursors.Hand;
            typesbtn.FlatAppearance.BorderSize = 0;
            typesbtn.FlatStyle = FlatStyle.Flat;
            typesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            typesbtn.Location = new Point(561, 3);
            typesbtn.Name = "typesbtn";
            typesbtn.Size = new Size(162, 35);
            typesbtn.TabIndex = 28;
            typesbtn.Text = "Видове артефакти";
            typesbtn.UseVisualStyleBackColor = false;
            typesbtn.Click += typesbtn_Click;
            // 
            // shapesbtn
            // 
            shapesbtn.BackColor = Color.NavajoWhite;
            shapesbtn.Cursor = Cursors.Hand;
            shapesbtn.FlatAppearance.BorderSize = 0;
            shapesbtn.FlatStyle = FlatStyle.Flat;
            shapesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            shapesbtn.Location = new Point(747, 3);
            shapesbtn.Name = "shapesbtn";
            shapesbtn.Size = new Size(162, 35);
            shapesbtn.TabIndex = 29;
            shapesbtn.Text = "Форми";
            shapesbtn.UseVisualStyleBackColor = false;
            shapesbtn.Click += shapesbtn_Click;
            // 
            // materialsbtn
            // 
            materialsbtn.BackColor = Color.NavajoWhite;
            materialsbtn.Cursor = Cursors.Hand;
            materialsbtn.FlatAppearance.BorderSize = 0;
            materialsbtn.FlatStyle = FlatStyle.Flat;
            materialsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            materialsbtn.Location = new Point(933, 3);
            materialsbtn.Name = "materialsbtn";
            materialsbtn.Size = new Size(162, 35);
            materialsbtn.TabIndex = 30;
            materialsbtn.Text = "Материали";
            materialsbtn.UseVisualStyleBackColor = false;
            materialsbtn.Click += materialsbtn_Click;
            // 
            // quieriesbtn
            // 
            quieriesbtn.BackColor = Color.NavajoWhite;
            quieriesbtn.Cursor = Cursors.Hand;
            quieriesbtn.FlatAppearance.BorderSize = 0;
            quieriesbtn.FlatStyle = FlatStyle.Flat;
            quieriesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesbtn.Location = new Point(1677, 3);
            quieriesbtn.Name = "quieriesbtn";
            quieriesbtn.Size = new Size(165, 35);
            quieriesbtn.TabIndex = 31;
            quieriesbtn.Text = "Заявки";
            quieriesbtn.UseVisualStyleBackColor = false;
            quieriesbtn.Click += queriesbtn_Click;
            // 
            // artefactsbtn
            // 
            artefactsbtn.BackColor = Color.NavajoWhite;
            artefactsbtn.Cursor = Cursors.Hand;
            artefactsbtn.FlatAppearance.BorderSize = 0;
            artefactsbtn.FlatStyle = FlatStyle.Flat;
            artefactsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsbtn.Location = new Point(189, 3);
            artefactsbtn.Name = "artefactsbtn";
            artefactsbtn.Size = new Size(162, 35);
            artefactsbtn.TabIndex = 32;
            artefactsbtn.Text = "Артефакти";
            artefactsbtn.UseVisualStyleBackColor = false;
            artefactsbtn.Click += artefactsbtn_Click;
            // 
            // museumsbtn
            // 
            museumsbtn.BackColor = Color.NavajoWhite;
            museumsbtn.Cursor = Cursors.Hand;
            museumsbtn.FlatAppearance.BorderSize = 0;
            museumsbtn.FlatStyle = FlatStyle.Flat;
            museumsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            museumsbtn.Location = new Point(1119, 3);
            museumsbtn.Name = "museumsbtn";
            museumsbtn.Size = new Size(162, 35);
            museumsbtn.TabIndex = 33;
            museumsbtn.Text = "Музеи";
            museumsbtn.UseVisualStyleBackColor = false;
            museumsbtn.Click += museumsbtn_Click;
            // 
            // collectionsbtn
            // 
            collectionsbtn.BackColor = Color.NavajoWhite;
            collectionsbtn.Cursor = Cursors.Hand;
            collectionsbtn.Enabled = false;
            collectionsbtn.FlatAppearance.BorderSize = 0;
            collectionsbtn.FlatStyle = FlatStyle.Flat;
            collectionsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsbtn.Location = new Point(1491, 3);
            collectionsbtn.Name = "collectionsbtn";
            collectionsbtn.Size = new Size(162, 35);
            collectionsbtn.TabIndex = 34;
            collectionsbtn.Text = "Сбирки";
            collectionsbtn.UseVisualStyleBackColor = false;
            // 
            // assesmentProtocolbtn
            // 
            assesmentProtocolbtn.BackColor = Color.NavajoWhite;
            assesmentProtocolbtn.Cursor = Cursors.Hand;
            assesmentProtocolbtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolbtn.FlatStyle = FlatStyle.Flat;
            assesmentProtocolbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolbtn.Location = new Point(1305, 3);
            assesmentProtocolbtn.Name = "assesmentProtocolbtn";
            assesmentProtocolbtn.Size = new Size(162, 35);
            assesmentProtocolbtn.TabIndex = 35;
            assesmentProtocolbtn.Text = "Оц. протокол";
            assesmentProtocolbtn.UseVisualStyleBackColor = false;
            assesmentProtocolbtn.Click += assesmentProtocolbtn_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(quieriesbtn, 9, 0);
            tableLayoutPanel1.Controls.Add(addNewbtn, 0, 3);
            tableLayoutPanel1.Controls.Add(updatebtn, 0, 4);
            tableLayoutPanel1.Controls.Add(collectionsbtn, 8, 0);
            tableLayoutPanel1.Controls.Add(assesmentProtocolbtn, 7, 0);
            tableLayoutPanel1.Controls.Add(menubtn, 0, 0);
            tableLayoutPanel1.Controls.Add(artefactsbtn, 1, 0);
            tableLayoutPanel1.Controls.Add(museumsbtn, 6, 0);
            tableLayoutPanel1.Controls.Add(sectionsbtn, 2, 0);
            tableLayoutPanel1.Controls.Add(typesbtn, 3, 0);
            tableLayoutPanel1.Controls.Add(materialsbtn, 5, 0);
            tableLayoutPanel1.Controls.Add(shapesbtn, 4, 0);
            tableLayoutPanel1.Controls.Add(resetBtn, 0, 6);
            tableLayoutPanel1.Controls.Add(deletebtn, 0, 5);
            tableLayoutPanel1.Controls.Add(collectionNameTxt, 0, 2);
            tableLayoutPanel1.Controls.Add(collectionIdTxt, 0, 1);
            tableLayoutPanel1.Controls.Add(materialDataGrid, 3, 1);
            tableLayoutPanel1.Location = new Point(30, 12);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 7;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.69991446F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.3833466F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.3833466F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.3833466F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.3833466F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.3833466F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 15.3833466F));
            tableLayoutPanel1.Size = new Size(1869, 975);
            tableLayoutPanel1.TabIndex = 54;
            // 
            // CollectionsMuseum
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(1024, 724);
            Name = "CollectionsMuseum";
            Text = "Сбирки";
            Load += Collections_Load;
            ((System.ComponentModel.ISupportInitialize)materialDataGrid).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button updatebtn;
        private Button deletebtn;
        private Button addNewbtn;
        private DataGridView materialDataGrid;
        private TextBox collectionNameTxt;
        private Button resetBtn;
        private TextBox collectionIdTxt;
        private TableLayoutPanel tableLayoutPanel1;
        private Button quieriesbtn;
        private Button collectionsbtn;
        private Button assesmentProtocolbtn;
        private Button menubtn;
        private Button artefactsbtn;
        private Button museumsbtn;
        private Button sectionsbtn;
        private Button typesbtn;
        private Button materialsbtn;
        private Button shapesbtn;
    }
}