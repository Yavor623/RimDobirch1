﻿namespace RIMDobrich1
{
    partial class DirectorMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            createAccountButton = new Button();
            deleteAccountButton = new Button();
            menuButton = new Button();
            panel1 = new Panel();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // createAccountButton
            // 
            createAccountButton.BackColor = Color.NavajoWhite;
            createAccountButton.FlatAppearance.BorderSize = 0;
            createAccountButton.FlatStyle = FlatStyle.Flat;
            createAccountButton.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            createAccountButton.Location = new Point(671, 284);
            createAccountButton.Name = "createAccountButton";
            createAccountButton.Size = new Size(536, 95);
            createAccountButton.TabIndex = 0;
            createAccountButton.Text = "Създаване на акаунт";
            createAccountButton.UseVisualStyleBackColor = false;
            createAccountButton.Click += createAccountButton_Click;
            // 
            // deleteAccountButton
            // 
            deleteAccountButton.BackColor = Color.NavajoWhite;
            deleteAccountButton.FlatAppearance.BorderSize = 0;
            deleteAccountButton.FlatStyle = FlatStyle.Flat;
            deleteAccountButton.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            deleteAccountButton.Location = new Point(671, 463);
            deleteAccountButton.Name = "deleteAccountButton";
            deleteAccountButton.Size = new Size(536, 95);
            deleteAccountButton.TabIndex = 1;
            deleteAccountButton.Text = "Изтриване на акаунт";
            deleteAccountButton.UseVisualStyleBackColor = false;
            deleteAccountButton.Click += deleteAccountButton_Click;
            // 
            // menuButton
            // 
            menuButton.BackColor = Color.NavajoWhite;
            menuButton.FlatAppearance.BorderSize = 0;
            menuButton.FlatStyle = FlatStyle.Flat;
            menuButton.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            menuButton.Location = new Point(671, 118);
            menuButton.Name = "menuButton";
            menuButton.Size = new Size(536, 95);
            menuButton.TabIndex = 2;
            menuButton.Text = "Меню";
            menuButton.UseVisualStyleBackColor = false;
            menuButton.Click += menuButton_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Tan;
            panel1.Controls.Add(menuButton);
            panel1.Controls.Add(deleteAccountButton);
            panel1.Controls.Add(createAccountButton);
            panel1.Location = new Point(31, 341);
            panel1.Name = "panel1";
            panel1.Size = new Size(1865, 625);
            panel1.TabIndex = 3;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Location = new Point(394, 109);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(250, 125);
            tableLayoutPanel1.TabIndex = 4;
            // 
            // DirectorMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1924, 1055);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(panel1);
            MinimumSize = new Size(1024, 724);
            Name = "DirectorMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Меню за директори";
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button createAccountButton;
        private Button deleteAccountButton;
        private Button menuButton;
        private Panel panel1;
        private TableLayoutPanel tableLayoutPanel1;
    }
}