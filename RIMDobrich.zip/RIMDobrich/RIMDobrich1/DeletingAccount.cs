﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class DeletingAccount : Form
    {
        public string DirectorPassword { get; set; }
        /*public string DeletedUsername
        {
            get
            {
                return usernameTextBox.Text;
            }
            set
            {
                value= usernameTextBox.Text;
            }
        }*/
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataAdapter DtA = new MySqlDataAdapter();
        MySqlDataReader sqlRd;
        DataSet DS = new DataSet();

        String server = "127.0.0.1";
        String username = "root";
        String password = "";
        String database = "rim_dobrich";
        public DeletingAccount()
        {
            InitializeComponent();
        }
        public DeletingAccount(string directorPassword)
        {
            this.DirectorPassword = directorPassword;
            InitializeComponent();
        }



        private void logInButton_Click(object sender, EventArgs e)
        {
            DeletingAccountProtection deletingAccountProtection = new DeletingAccountProtection(DirectorPassword, usernameTextBox.Text);
            deletingAccountProtection.Show();
        }

        private void directorMenuLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DirectorMenu directorMenu = new DirectorMenu();
            DeletingAccount deletingAccount = new DeletingAccount();
            directorMenu.Show();
            this.Hide();
            deletingAccount.Close();
        }
    }
}
