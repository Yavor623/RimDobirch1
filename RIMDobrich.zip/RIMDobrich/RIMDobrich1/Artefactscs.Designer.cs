﻿namespace RIMDobrich1
{
    partial class Artefacts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Artefacts));
            bindingSource1 = new BindingSource(components);
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            updateBtn = new Button();
            deleteBtn = new Button();
            addNewBtn = new Button();
            indexTxt = new TextBox();
            artefactsDataGrid = new DataGridView();
            sectionsComboBox = new ComboBox();
            nameOfMuseumComboBox = new ComboBox();
            techniqueTxt = new TextBox();
            sizeTxt = new TextBox();
            inscriptionOrDateTxt = new TextBox();
            cipherTxt = new TextBox();
            artefactNameTxt = new TextBox();
            oldInventoryIdTxt = new TextBox();
            conditionOfArtefactTxt = new TextBox();
            amountOfArtefactTxt = new TextBox();
            eraTxt = new TextBox();
            madeTheScientificPassportTxt = new TextBox();
            copiesMadeTxt = new TextBox();
            participationInExhibitionsTxt = new TextBox();
            conservationAndRestorationTxt = new TextBox();
            scientificPublicationsTxt = new TextBox();
            bibliographicEnquiryTxt = new TextBox();
            registrationIdOfNMFTxt = new TextBox();
            idOfPhotoNegativeTxt = new TextBox();
            locationOfFindingTxt = new TextBox();
            storageLocationTxt = new TextBox();
            sellerOrDonaterTxt = new TextBox();
            historicalEnquiryTxt = new TextBox();
            idOfActOfAdmissionTxt = new TextBox();
            marriageProtocolAndActOfLiquidationTxt = new TextBox();
            typeComboBox = new ComboBox();
            dateOfRegistrationLabel = new Label();
            dateOfRegistration = new DateTimePicker();
            dateOfCreationOfTheScientificPassportTxt = new DateTimePicker();
            dateOfCreationOfTheScientificPassportLabel = new Label();
            pictureBox = new PictureBox();
            openPictureFileDialog = new OpenFileDialog();
            pictureBtn = new Button();
            dateOfAssesmentProtocol = new DateTimePicker();
            priceOfAssesmentProtocolTxt = new TextBox();
            searchTxt = new TextBox();
            shapeComboBox = new ComboBox();
            materialComboBox = new ComboBox();
            assesmentProtocolIdComboBox = new ComboBox();
            identificationTxt = new TextBox();
            dateOfAssesmentProtocolLabel = new Label();
            collectionscb = new ComboBox();
            resetBtn = new Button();
            weightTxt = new TextBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            menuBtn = new Button();
            sectionsBtn = new Button();
            artefactsBtn = new Button();
            typesBtn = new Button();
            shapesBtn = new Button();
            materialsBtn = new Button();
            museumsBtn = new Button();
            assesmentProtocolBtn = new Button();
            collectionsbtn = new Button();
            quieriesbtn = new Button();
            searchBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)artefactsDataGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(-643, 111);
            label3.Name = "label3";
            label3.Size = new Size(186, 35);
            label3.TabIndex = 38;
            label3.Text = "Име на секция";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(-643, 4);
            label2.Name = "label2";
            label2.Size = new Size(99, 35);
            label2.TabIndex = 37;
            label2.Text = "Индекс";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(-637, 293);
            label1.Name = "label1";
            label1.Size = new Size(110, 35);
            label1.TabIndex = 36;
            label1.Text = "Търсене";
            // 
            // updateBtn
            // 
            updateBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(updateBtn, 3);
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            updateBtn.Location = new Point(1305, 864);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(554, 35);
            updateBtn.TabIndex = 33;
            updateBtn.Text = "Обнови";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updatebtn_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(deleteBtn, 3);
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            deleteBtn.Location = new Point(747, 907);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(552, 38);
            deleteBtn.TabIndex = 32;
            deleteBtn.Text = "Премахни";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deletebtn_Click;
            // 
            // addNewBtn
            // 
            addNewBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(addNewBtn, 3);
            addNewBtn.Cursor = Cursors.Hand;
            addNewBtn.FlatStyle = FlatStyle.Flat;
            addNewBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            addNewBtn.Location = new Point(747, 864);
            addNewBtn.Name = "addNewBtn";
            addNewBtn.Size = new Size(552, 37);
            addNewBtn.TabIndex = 31;
            addNewBtn.Text = "Добави";
            addNewBtn.UseVisualStyleBackColor = false;
            addNewBtn.Click += addNewbtn_Click;
            // 
            // indexTxt
            // 
            indexTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            indexTxt.Location = new Point(3, 90);
            indexTxt.MaxLength = 99;
            indexTxt.Name = "indexTxt";
            indexTxt.PlaceholderText = "Индекс";
            indexTxt.Size = new Size(180, 35);
            indexTxt.TabIndex = 29;
            // 
            // artefactsDataGrid
            // 
            artefactsDataGrid.AllowUserToAddRows = false;
            artefactsDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            artefactsDataGrid.BackgroundColor = Color.Tan;
            artefactsDataGrid.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            artefactsDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tableLayoutPanel1.SetColumnSpan(artefactsDataGrid, 6);
            artefactsDataGrid.Cursor = Cursors.PanNW;
            artefactsDataGrid.Location = new Point(747, 90);
            artefactsDataGrid.MultiSelect = false;
            artefactsDataGrid.Name = "artefactsDataGrid";
            artefactsDataGrid.ReadOnly = true;
            artefactsDataGrid.RowHeadersWidth = 51;
            tableLayoutPanel1.SetRowSpan(artefactsDataGrid, 18);
            artefactsDataGrid.RowTemplate.Height = 29;
            artefactsDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            artefactsDataGrid.Size = new Size(1112, 768);
            artefactsDataGrid.TabIndex = 28;
            artefactsDataGrid.CellClick += artefactsDataGrid_CellClick;
            // 
            // sectionsComboBox
            // 
            sectionsComboBox.DropDownHeight = 250;
            sectionsComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsComboBox.ForeColor = SystemColors.ControlText;
            sectionsComboBox.FormattingEnabled = true;
            sectionsComboBox.IntegralHeight = false;
            sectionsComboBox.Location = new Point(375, 90);
            sectionsComboBox.Name = "sectionsComboBox";
            sectionsComboBox.Size = new Size(180, 36);
            sectionsComboBox.TabIndex = 40;
            sectionsComboBox.Text = "Отдели";
            sectionsComboBox.KeyDown += nameOfMuseumComboBox_KeyDown;
            // 
            // nameOfMuseumComboBox
            // 
            nameOfMuseumComboBox.DropDownHeight = 250;
            nameOfMuseumComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            nameOfMuseumComboBox.ForeColor = SystemColors.ControlText;
            nameOfMuseumComboBox.FormattingEnabled = true;
            nameOfMuseumComboBox.IntegralHeight = false;
            nameOfMuseumComboBox.Location = new Point(189, 90);
            nameOfMuseumComboBox.Name = "nameOfMuseumComboBox";
            nameOfMuseumComboBox.RightToLeft = RightToLeft.No;
            nameOfMuseumComboBox.Size = new Size(180, 36);
            nameOfMuseumComboBox.TabIndex = 41;
            nameOfMuseumComboBox.Text = "Име на музей";
            nameOfMuseumComboBox.KeyDown += nameOfMuseumComboBox_KeyDown;
            // 
            // techniqueTxt
            // 
            tableLayoutPanel1.SetColumnSpan(techniqueTxt, 2);
            techniqueTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            techniqueTxt.Location = new Point(375, 262);
            techniqueTxt.MaxLength = 50;
            techniqueTxt.Name = "techniqueTxt";
            techniqueTxt.PlaceholderText = "Техника";
            techniqueTxt.Size = new Size(366, 35);
            techniqueTxt.TabIndex = 43;
            // 
            // sizeTxt
            // 
            sizeTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            sizeTxt.Location = new Point(3, 391);
            sizeTxt.MaxLength = 40;
            sizeTxt.Name = "sizeTxt";
            sizeTxt.PlaceholderText = "Размер";
            sizeTxt.Size = new Size(180, 35);
            sizeTxt.TabIndex = 45;
            // 
            // inscriptionOrDateTxt
            // 
            tableLayoutPanel1.SetColumnSpan(inscriptionOrDateTxt, 4);
            inscriptionOrDateTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            inscriptionOrDateTxt.Location = new Point(3, 305);
            inscriptionOrDateTxt.MaxLength = 400;
            inscriptionOrDateTxt.Multiline = true;
            inscriptionOrDateTxt.Name = "inscriptionOrDateTxt";
            inscriptionOrDateTxt.PlaceholderText = "Надпис или дата";
            tableLayoutPanel1.SetRowSpan(inscriptionOrDateTxt, 2);
            inscriptionOrDateTxt.Size = new Size(738, 73);
            inscriptionOrDateTxt.TabIndex = 46;
            // 
            // cipherTxt
            // 
            cipherTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            cipherTxt.Location = new Point(561, 133);
            cipherTxt.MaxLength = 10;
            cipherTxt.Name = "cipherTxt";
            cipherTxt.PlaceholderText = "Шифър";
            cipherTxt.Size = new Size(180, 35);
            cipherTxt.TabIndex = 48;
            // 
            // artefactNameTxt
            // 
            tableLayoutPanel1.SetColumnSpan(artefactNameTxt, 2);
            artefactNameTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            artefactNameTxt.Location = new Point(189, 133);
            artefactNameTxt.MaxLength = 100;
            artefactNameTxt.Name = "artefactNameTxt";
            artefactNameTxt.PlaceholderText = "Име на артефакта";
            artefactNameTxt.Size = new Size(366, 35);
            artefactNameTxt.TabIndex = 49;
            // 
            // oldInventoryIdTxt
            // 
            oldInventoryIdTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            oldInventoryIdTxt.Location = new Point(189, 219);
            oldInventoryIdTxt.MaxLength = 10;
            oldInventoryIdTxt.Name = "oldInventoryIdTxt";
            oldInventoryIdTxt.PlaceholderText = "Стар инвентарен номер";
            oldInventoryIdTxt.Size = new Size(180, 35);
            oldInventoryIdTxt.TabIndex = 50;
            // 
            // conditionOfArtefactTxt
            // 
            conditionOfArtefactTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            conditionOfArtefactTxt.Location = new Point(561, 391);
            conditionOfArtefactTxt.MaxLength = 30;
            conditionOfArtefactTxt.Name = "conditionOfArtefactTxt";
            conditionOfArtefactTxt.PlaceholderText = "Състояние на ДПК";
            conditionOfArtefactTxt.Size = new Size(180, 35);
            conditionOfArtefactTxt.TabIndex = 51;
            // 
            // amountOfArtefactTxt
            // 
            amountOfArtefactTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            amountOfArtefactTxt.Location = new Point(3, 434);
            amountOfArtefactTxt.MaxLength = 6;
            amountOfArtefactTxt.Name = "amountOfArtefactTxt";
            amountOfArtefactTxt.PlaceholderText = "Брой на ДПК";
            amountOfArtefactTxt.Size = new Size(180, 35);
            amountOfArtefactTxt.TabIndex = 52;
            // 
            // eraTxt
            // 
            eraTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            eraTxt.Location = new Point(375, 391);
            eraTxt.MaxLength = 50;
            eraTxt.Name = "eraTxt";
            eraTxt.PlaceholderText = "Епоха";
            eraTxt.Size = new Size(180, 35);
            eraTxt.TabIndex = 53;
            // 
            // madeTheScientificPassportTxt
            // 
            tableLayoutPanel1.SetColumnSpan(madeTheScientificPassportTxt, 2);
            madeTheScientificPassportTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            madeTheScientificPassportTxt.Location = new Point(375, 606);
            madeTheScientificPassportTxt.MaxLength = 100;
            madeTheScientificPassportTxt.Name = "madeTheScientificPassportTxt";
            madeTheScientificPassportTxt.PlaceholderText = "Изготвил научния паспорт";
            madeTheScientificPassportTxt.Size = new Size(366, 35);
            madeTheScientificPassportTxt.TabIndex = 57;
            // 
            // copiesMadeTxt
            // 
            copiesMadeTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            copiesMadeTxt.Location = new Point(3, 606);
            copiesMadeTxt.MaxLength = 5;
            copiesMadeTxt.Name = "copiesMadeTxt";
            copiesMadeTxt.PlaceholderText = "Направени копия";
            copiesMadeTxt.Size = new Size(180, 35);
            copiesMadeTxt.TabIndex = 58;
            // 
            // participationInExhibitionsTxt
            // 
            participationInExhibitionsTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            participationInExhibitionsTxt.Location = new Point(561, 563);
            participationInExhibitionsTxt.MaxLength = 5;
            participationInExhibitionsTxt.Name = "participationInExhibitionsTxt";
            participationInExhibitionsTxt.PlaceholderText = "Участие в изл.";
            participationInExhibitionsTxt.Size = new Size(180, 35);
            participationInExhibitionsTxt.TabIndex = 59;
            // 
            // conservationAndRestorationTxt
            // 
            conservationAndRestorationTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            conservationAndRestorationTxt.Location = new Point(375, 563);
            conservationAndRestorationTxt.MaxLength = 5;
            conservationAndRestorationTxt.Name = "conservationAndRestorationTxt";
            conservationAndRestorationTxt.PlaceholderText = "Консерв. и реставр.";
            conservationAndRestorationTxt.Size = new Size(180, 35);
            conservationAndRestorationTxt.TabIndex = 60;
            // 
            // scientificPublicationsTxt
            // 
            scientificPublicationsTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            scientificPublicationsTxt.Location = new Point(189, 563);
            scientificPublicationsTxt.MaxLength = 5;
            scientificPublicationsTxt.Name = "scientificPublicationsTxt";
            scientificPublicationsTxt.PlaceholderText = "Научни публик.";
            scientificPublicationsTxt.Size = new Size(180, 35);
            scientificPublicationsTxt.TabIndex = 61;
            // 
            // bibliographicEnquiryTxt
            // 
            bibliographicEnquiryTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            bibliographicEnquiryTxt.Location = new Point(3, 563);
            bibliographicEnquiryTxt.MaxLength = 5;
            bibliographicEnquiryTxt.Name = "bibliographicEnquiryTxt";
            bibliographicEnquiryTxt.PlaceholderText = "Библ. справка за ДПК";
            bibliographicEnquiryTxt.Size = new Size(180, 35);
            bibliographicEnquiryTxt.TabIndex = 62;
            // 
            // registrationIdOfNMFTxt
            // 
            registrationIdOfNMFTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            registrationIdOfNMFTxt.Location = new Point(561, 520);
            registrationIdOfNMFTxt.MaxLength = 15;
            registrationIdOfNMFTxt.Name = "registrationIdOfNMFTxt";
            registrationIdOfNMFTxt.PlaceholderText = "Регистрационен номер на НМФ";
            registrationIdOfNMFTxt.Size = new Size(180, 35);
            registrationIdOfNMFTxt.TabIndex = 63;
            // 
            // idOfPhotoNegativeTxt
            // 
            idOfPhotoNegativeTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            idOfPhotoNegativeTxt.Location = new Point(375, 520);
            idOfPhotoNegativeTxt.MaxLength = 10;
            idOfPhotoNegativeTxt.Name = "idOfPhotoNegativeTxt";
            idOfPhotoNegativeTxt.PlaceholderText = "Номер на фотонегатива";
            idOfPhotoNegativeTxt.Size = new Size(180, 35);
            idOfPhotoNegativeTxt.TabIndex = 64;
            // 
            // locationOfFindingTxt
            // 
            locationOfFindingTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            locationOfFindingTxt.Location = new Point(189, 520);
            locationOfFindingTxt.MaxLength = 125;
            locationOfFindingTxt.Name = "locationOfFindingTxt";
            locationOfFindingTxt.PlaceholderText = "Местонахождение";
            locationOfFindingTxt.Size = new Size(180, 35);
            locationOfFindingTxt.TabIndex = 65;
            // 
            // storageLocationTxt
            // 
            storageLocationTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            storageLocationTxt.Location = new Point(3, 520);
            storageLocationTxt.Name = "storageLocationTxt";
            storageLocationTxt.PlaceholderText = "Местосъхранение";
            storageLocationTxt.Size = new Size(180, 35);
            storageLocationTxt.TabIndex = 66;
            // 
            // sellerOrDonaterTxt
            // 
            tableLayoutPanel1.SetColumnSpan(sellerOrDonaterTxt, 2);
            sellerOrDonaterTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            sellerOrDonaterTxt.Location = new Point(375, 434);
            sellerOrDonaterTxt.MaxLength = 100;
            sellerOrDonaterTxt.Name = "sellerOrDonaterTxt";
            sellerOrDonaterTxt.PlaceholderText = "От кого е купен или подарен";
            sellerOrDonaterTxt.Size = new Size(366, 35);
            sellerOrDonaterTxt.TabIndex = 68;
            // 
            // historicalEnquiryTxt
            // 
            historicalEnquiryTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            historicalEnquiryTxt.Location = new Point(189, 434);
            historicalEnquiryTxt.MaxLength = 6;
            historicalEnquiryTxt.Name = "historicalEnquiryTxt";
            historicalEnquiryTxt.PlaceholderText = "Историческа справка";
            historicalEnquiryTxt.Size = new Size(180, 35);
            historicalEnquiryTxt.TabIndex = 69;
            // 
            // idOfActOfAdmissionTxt
            // 
            idOfActOfAdmissionTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            idOfActOfAdmissionTxt.Location = new Point(561, 219);
            idOfActOfAdmissionTxt.MaxLength = 20;
            idOfActOfAdmissionTxt.Multiline = true;
            idOfActOfAdmissionTxt.Name = "idOfActOfAdmissionTxt";
            idOfActOfAdmissionTxt.PlaceholderText = "Номер на акта за приемане и предаване";
            idOfActOfAdmissionTxt.Size = new Size(180, 35);
            idOfActOfAdmissionTxt.TabIndex = 71;
            // 
            // marriageProtocolAndActOfLiquidationTxt
            // 
            marriageProtocolAndActOfLiquidationTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            marriageProtocolAndActOfLiquidationTxt.Location = new Point(189, 606);
            marriageProtocolAndActOfLiquidationTxt.MaxLength = 5;
            marriageProtocolAndActOfLiquidationTxt.Name = "marriageProtocolAndActOfLiquidationTxt";
            marriageProtocolAndActOfLiquidationTxt.PlaceholderText = "ПБАЛ";
            marriageProtocolAndActOfLiquidationTxt.Size = new Size(180, 35);
            marriageProtocolAndActOfLiquidationTxt.TabIndex = 72;
            // 
            // typeComboBox
            // 
            typeComboBox.DropDownHeight = 250;
            typeComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            typeComboBox.ForeColor = SystemColors.ControlText;
            typeComboBox.FormattingEnabled = true;
            typeComboBox.IntegralHeight = false;
            typeComboBox.Location = new Point(3, 133);
            typeComboBox.MaxLength = 120;
            typeComboBox.Name = "typeComboBox";
            typeComboBox.Size = new Size(180, 36);
            typeComboBox.TabIndex = 73;
            typeComboBox.Text = "Видове артефакти";
            typeComboBox.TextUpdate += typeComboBox_TextUpdate;
            typeComboBox.Click += typeComboBox_Click;
            typeComboBox.KeyDown += typeComboBox_KeyDown;
            // 
            // dateOfRegistrationLabel
            // 
            dateOfRegistrationLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            dateOfRegistrationLabel.AutoSize = true;
            dateOfRegistrationLabel.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfRegistrationLabel.Location = new Point(3, 194);
            dateOfRegistrationLabel.Name = "dateOfRegistrationLabel";
            dateOfRegistrationLabel.Size = new Size(173, 22);
            dateOfRegistrationLabel.TabIndex = 74;
            dateOfRegistrationLabel.Text = "Дата на регистрация";
            // 
            // dateOfRegistration
            // 
            dateOfRegistration.CalendarFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfRegistration.Cursor = Cursors.IBeam;
            dateOfRegistration.CustomFormat = "yyyy-MM-dd";
            dateOfRegistration.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfRegistration.Format = DateTimePickerFormat.Custom;
            dateOfRegistration.Location = new Point(3, 219);
            dateOfRegistration.Name = "dateOfRegistration";
            dateOfRegistration.Size = new Size(180, 34);
            dateOfRegistration.TabIndex = 75;
            // 
            // dateOfCreationOfTheScientificPassportTxt
            // 
            tableLayoutPanel1.SetColumnSpan(dateOfCreationOfTheScientificPassportTxt, 2);
            dateOfCreationOfTheScientificPassportTxt.Cursor = Cursors.IBeam;
            dateOfCreationOfTheScientificPassportTxt.CustomFormat = "yyyy-MM-dd";
            dateOfCreationOfTheScientificPassportTxt.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfCreationOfTheScientificPassportTxt.Format = DateTimePickerFormat.Custom;
            dateOfCreationOfTheScientificPassportTxt.Location = new Point(3, 735);
            dateOfCreationOfTheScientificPassportTxt.Name = "dateOfCreationOfTheScientificPassportTxt";
            dateOfCreationOfTheScientificPassportTxt.Size = new Size(366, 32);
            dateOfCreationOfTheScientificPassportTxt.TabIndex = 76;
            // 
            // dateOfCreationOfTheScientificPassportLabel
            // 
            dateOfCreationOfTheScientificPassportLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            dateOfCreationOfTheScientificPassportLabel.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(dateOfCreationOfTheScientificPassportLabel, 2);
            dateOfCreationOfTheScientificPassportLabel.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfCreationOfTheScientificPassportLabel.Location = new Point(3, 710);
            dateOfCreationOfTheScientificPassportLabel.Name = "dateOfCreationOfTheScientificPassportLabel";
            dateOfCreationOfTheScientificPassportLabel.Size = new Size(314, 22);
            dateOfCreationOfTheScientificPassportLabel.TabIndex = 77;
            dateOfCreationOfTheScientificPassportLabel.Text = "Дата на съставяне на научния паспорт";
            // 
            // pictureBox
            // 
            pictureBox.BorderStyle = BorderStyle.FixedSingle;
            tableLayoutPanel1.SetColumnSpan(pictureBox, 2);
            pictureBox.Location = new Point(375, 692);
            pictureBox.Name = "pictureBox";
            tableLayoutPanel1.SetRowSpan(pictureBox, 6);
            pictureBox.Size = new Size(366, 253);
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox.TabIndex = 78;
            pictureBox.TabStop = false;
            // 
            // openPictureFileDialog
            // 
            openPictureFileDialog.Filter = "Image files =(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp; *.png";
            openPictureFileDialog.Title = "Choose a file";
            // 
            // pictureBtn
            // 
            pictureBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(pictureBtn, 2);
            pictureBtn.Cursor = Cursors.Hand;
            pictureBtn.FlatStyle = FlatStyle.Flat;
            pictureBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            pictureBtn.Location = new Point(3, 907);
            pictureBtn.Name = "pictureBtn";
            pictureBtn.Size = new Size(366, 38);
            pictureBtn.TabIndex = 79;
            pictureBtn.Text = "Добави снимка";
            pictureBtn.UseVisualStyleBackColor = false;
            pictureBtn.Click += picturebtn_Click;
            // 
            // dateOfAssesmentProtocol
            // 
            dateOfAssesmentProtocol.Cursor = Cursors.IBeam;
            dateOfAssesmentProtocol.CustomFormat = "yyyy-MM-dd";
            dateOfAssesmentProtocol.Enabled = false;
            dateOfAssesmentProtocol.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfAssesmentProtocol.Format = DateTimePickerFormat.Custom;
            dateOfAssesmentProtocol.Location = new Point(375, 477);
            dateOfAssesmentProtocol.Name = "dateOfAssesmentProtocol";
            dateOfAssesmentProtocol.Size = new Size(180, 34);
            dateOfAssesmentProtocol.TabIndex = 81;
            // 
            // priceOfAssesmentProtocolTxt
            // 
            priceOfAssesmentProtocolTxt.Enabled = false;
            priceOfAssesmentProtocolTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            priceOfAssesmentProtocolTxt.Location = new Point(561, 477);
            priceOfAssesmentProtocolTxt.Name = "priceOfAssesmentProtocolTxt";
            priceOfAssesmentProtocolTxt.PlaceholderText = "Сума";
            priceOfAssesmentProtocolTxt.Size = new Size(180, 35);
            priceOfAssesmentProtocolTxt.TabIndex = 82;
            // 
            // searchTxt
            // 
            tableLayoutPanel1.SetColumnSpan(searchTxt, 2);
            searchTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            searchTxt.Location = new Point(3, 821);
            searchTxt.Name = "searchTxt";
            searchTxt.PlaceholderText = "Търси по име";
            searchTxt.Size = new Size(366, 35);
            searchTxt.TabIndex = 83;
            // 
            // shapeComboBox
            // 
            shapeComboBox.DropDownHeight = 250;
            shapeComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            shapeComboBox.ForeColor = SystemColors.ControlText;
            shapeComboBox.FormattingEnabled = true;
            shapeComboBox.IntegralHeight = false;
            shapeComboBox.Location = new Point(375, 219);
            shapeComboBox.Name = "shapeComboBox";
            shapeComboBox.RightToLeft = RightToLeft.No;
            shapeComboBox.Size = new Size(180, 36);
            shapeComboBox.TabIndex = 85;
            shapeComboBox.Text = "Форма";
            shapeComboBox.KeyDown += nameOfMuseumComboBox_KeyDown;
            // 
            // materialComboBox
            // 
            tableLayoutPanel1.SetColumnSpan(materialComboBox, 2);
            materialComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            materialComboBox.ForeColor = SystemColors.ControlText;
            materialComboBox.FormattingEnabled = true;
            materialComboBox.Location = new Point(3, 262);
            materialComboBox.Name = "materialComboBox";
            materialComboBox.RightToLeft = RightToLeft.No;
            materialComboBox.Size = new Size(366, 36);
            materialComboBox.TabIndex = 86;
            materialComboBox.Text = "Материал";
            materialComboBox.KeyDown += nameOfMuseumComboBox_KeyDown;
            // 
            // assesmentProtocolIdComboBox
            // 
            assesmentProtocolIdComboBox.DropDownHeight = 250;
            assesmentProtocolIdComboBox.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolIdComboBox.ForeColor = SystemColors.ControlText;
            assesmentProtocolIdComboBox.FormattingEnabled = true;
            assesmentProtocolIdComboBox.IntegralHeight = false;
            assesmentProtocolIdComboBox.Location = new Point(3, 477);
            assesmentProtocolIdComboBox.Name = "assesmentProtocolIdComboBox";
            assesmentProtocolIdComboBox.RightToLeft = RightToLeft.No;
            assesmentProtocolIdComboBox.Size = new Size(180, 36);
            assesmentProtocolIdComboBox.TabIndex = 87;
            assesmentProtocolIdComboBox.Text = "№ ОП";
            assesmentProtocolIdComboBox.SelectedIndexChanged += assesmentpridcb_SelectedIndexChanged;
            assesmentProtocolIdComboBox.KeyDown += nameOfMuseumComboBox_KeyDown;
            // 
            // identificationTxt
            // 
            tableLayoutPanel1.SetColumnSpan(identificationTxt, 2);
            identificationTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            identificationTxt.Location = new Point(3, 778);
            identificationTxt.MaxLength = 75;
            identificationTxt.Name = "identificationTxt";
            identificationTxt.PlaceholderText = "Идентификация";
            identificationTxt.Size = new Size(366, 35);
            identificationTxt.TabIndex = 88;
            // 
            // dateOfAssesmentProtocolLabel
            // 
            dateOfAssesmentProtocolLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            dateOfAssesmentProtocolLabel.AutoSize = true;
            dateOfAssesmentProtocolLabel.Font = new Font("Modern No. 20", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfAssesmentProtocolLabel.Location = new Point(263, 474);
            dateOfAssesmentProtocolLabel.Name = "dateOfAssesmentProtocolLabel";
            dateOfAssesmentProtocolLabel.Size = new Size(106, 22);
            dateOfAssesmentProtocolLabel.TabIndex = 89;
            dateOfAssesmentProtocolLabel.Text = "Дата на ОП:";
            // 
            // collectionscb
            // 
            collectionscb.DropDownHeight = 250;
            collectionscb.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            collectionscb.ForeColor = SystemColors.ControlText;
            collectionscb.FormattingEnabled = true;
            collectionscb.IntegralHeight = false;
            collectionscb.Location = new Point(561, 90);
            collectionscb.Name = "collectionscb";
            collectionscb.RightToLeft = RightToLeft.No;
            collectionscb.Size = new Size(180, 36);
            collectionscb.TabIndex = 90;
            collectionscb.Text = "Сбирки";
            collectionscb.KeyDown += nameOfMuseumComboBox_KeyDown;
            // 
            // resetBtn
            // 
            resetBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(resetBtn, 3);
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(1305, 907);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(554, 38);
            resetBtn.TabIndex = 91;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // weightTxt
            // 
            weightTxt.Font = new Font("Segoe UI", 12.5F, FontStyle.Regular, GraphicsUnit.Point);
            weightTxt.Location = new Point(189, 391);
            weightTxt.MaxLength = 40;
            weightTxt.Name = "weightTxt";
            weightTxt.PlaceholderText = "Тегло";
            weightTxt.Size = new Size(180, 35);
            weightTxt.TabIndex = 92;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(menuBtn, 0, 0);
            tableLayoutPanel1.Controls.Add(indexTxt, 0, 1);
            tableLayoutPanel1.Controls.Add(addNewBtn, 4, 19);
            tableLayoutPanel1.Controls.Add(nameOfMuseumComboBox, 1, 1);
            tableLayoutPanel1.Controls.Add(sectionsComboBox, 2, 1);
            tableLayoutPanel1.Controls.Add(collectionscb, 3, 1);
            tableLayoutPanel1.Controls.Add(typeComboBox, 0, 2);
            tableLayoutPanel1.Controls.Add(artefactNameTxt, 1, 2);
            tableLayoutPanel1.Controls.Add(cipherTxt, 3, 2);
            tableLayoutPanel1.Controls.Add(dateOfRegistrationLabel, 0, 3);
            tableLayoutPanel1.Controls.Add(dateOfRegistration, 0, 4);
            tableLayoutPanel1.Controls.Add(oldInventoryIdTxt, 1, 4);
            tableLayoutPanel1.Controls.Add(shapeComboBox, 2, 4);
            tableLayoutPanel1.Controls.Add(idOfActOfAdmissionTxt, 3, 4);
            tableLayoutPanel1.Controls.Add(materialComboBox, 0, 5);
            tableLayoutPanel1.Controls.Add(inscriptionOrDateTxt, 0, 6);
            tableLayoutPanel1.Controls.Add(sizeTxt, 0, 8);
            tableLayoutPanel1.Controls.Add(weightTxt, 1, 8);
            tableLayoutPanel1.Controls.Add(conditionOfArtefactTxt, 3, 8);
            tableLayoutPanel1.Controls.Add(amountOfArtefactTxt, 0, 9);
            tableLayoutPanel1.Controls.Add(historicalEnquiryTxt, 1, 9);
            tableLayoutPanel1.Controls.Add(sellerOrDonaterTxt, 2, 9);
            tableLayoutPanel1.Controls.Add(assesmentProtocolIdComboBox, 0, 10);
            tableLayoutPanel1.Controls.Add(dateOfAssesmentProtocol, 2, 10);
            tableLayoutPanel1.Controls.Add(priceOfAssesmentProtocolTxt, 3, 10);
            tableLayoutPanel1.Controls.Add(storageLocationTxt, 0, 11);
            tableLayoutPanel1.Controls.Add(locationOfFindingTxt, 1, 11);
            tableLayoutPanel1.Controls.Add(idOfPhotoNegativeTxt, 2, 11);
            tableLayoutPanel1.Controls.Add(registrationIdOfNMFTxt, 3, 11);
            tableLayoutPanel1.Controls.Add(bibliographicEnquiryTxt, 0, 12);
            tableLayoutPanel1.Controls.Add(scientificPublicationsTxt, 1, 12);
            tableLayoutPanel1.Controls.Add(conservationAndRestorationTxt, 2, 12);
            tableLayoutPanel1.Controls.Add(participationInExhibitionsTxt, 3, 12);
            tableLayoutPanel1.Controls.Add(copiesMadeTxt, 0, 13);
            tableLayoutPanel1.Controls.Add(marriageProtocolAndActOfLiquidationTxt, 1, 13);
            tableLayoutPanel1.Controls.Add(madeTheScientificPassportTxt, 2, 13);
            tableLayoutPanel1.Controls.Add(techniqueTxt, 2, 5);
            tableLayoutPanel1.Controls.Add(dateOfAssesmentProtocolLabel, 1, 10);
            tableLayoutPanel1.Controls.Add(artefactsDataGrid, 4, 1);
            tableLayoutPanel1.Controls.Add(sectionsBtn, 2, 0);
            tableLayoutPanel1.Controls.Add(artefactsBtn, 1, 0);
            tableLayoutPanel1.Controls.Add(typesBtn, 3, 0);
            tableLayoutPanel1.Controls.Add(shapesBtn, 4, 0);
            tableLayoutPanel1.Controls.Add(materialsBtn, 5, 0);
            tableLayoutPanel1.Controls.Add(museumsBtn, 6, 0);
            tableLayoutPanel1.Controls.Add(assesmentProtocolBtn, 7, 0);
            tableLayoutPanel1.Controls.Add(collectionsbtn, 8, 0);
            tableLayoutPanel1.Controls.Add(quieriesbtn, 9, 0);
            tableLayoutPanel1.Controls.Add(eraTxt, 2, 8);
            tableLayoutPanel1.Controls.Add(deleteBtn, 4, 20);
            tableLayoutPanel1.Controls.Add(updateBtn, 7, 19);
            tableLayoutPanel1.Controls.Add(resetBtn, 7, 20);
            tableLayoutPanel1.Controls.Add(pictureBtn, 0, 20);
            tableLayoutPanel1.Controls.Add(searchBtn, 0, 19);
            tableLayoutPanel1.Controls.Add(pictureBox, 2, 15);
            tableLayoutPanel1.Controls.Add(searchTxt, 0, 18);
            tableLayoutPanel1.Controls.Add(identificationTxt, 0, 17);
            tableLayoutPanel1.Controls.Add(dateOfCreationOfTheScientificPassportTxt, 0, 16);
            tableLayoutPanel1.Controls.Add(dateOfCreationOfTheScientificPassportLabel, 0, 15);
            tableLayoutPanel1.Location = new Point(12, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 22;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 9.108593F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.53828049F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.66408825F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(1862, 978);
            tableLayoutPanel1.TabIndex = 93;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.Cursor = Cursors.Hand;
            menuBtn.FlatAppearance.BorderSize = 0;
            menuBtn.FlatStyle = FlatStyle.Flat;
            menuBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(3, 3);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(180, 49);
            menuBtn.TabIndex = 0;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.Cursor = Cursors.Hand;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Flat;
            sectionsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(375, 3);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(178, 49);
            sectionsBtn.TabIndex = 93;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sections_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.Enabled = false;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Flat;
            artefactsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(189, 3);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(178, 49);
            artefactsBtn.TabIndex = 94;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.Cursor = Cursors.Hand;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Flat;
            typesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(561, 3);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(178, 49);
            typesBtn.TabIndex = 95;
            typesBtn.Text = "Видове артефакти";
            typesBtn.UseVisualStyleBackColor = false;
            typesBtn.Click += typesbtn_Click;
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.Cursor = Cursors.Hand;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Flat;
            shapesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(747, 3);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(178, 49);
            shapesBtn.TabIndex = 96;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesbtn_Click;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.Cursor = Cursors.Hand;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Flat;
            materialsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(933, 3);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(180, 49);
            materialsBtn.TabIndex = 30;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // museumsBtn
            // 
            museumsBtn.BackColor = Color.NavajoWhite;
            museumsBtn.FlatAppearance.BorderSize = 0;
            museumsBtn.FlatStyle = FlatStyle.Flat;
            museumsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            museumsBtn.Location = new Point(1119, 3);
            museumsBtn.Name = "museumsBtn";
            museumsBtn.Size = new Size(180, 49);
            museumsBtn.TabIndex = 33;
            museumsBtn.Text = "Музеи";
            museumsBtn.UseVisualStyleBackColor = false;
            museumsBtn.Click += museumsbtn_Click;
            // 
            // assesmentProtocolBtn
            // 
            assesmentProtocolBtn.BackColor = Color.NavajoWhite;
            assesmentProtocolBtn.Cursor = Cursors.Hand;
            assesmentProtocolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolBtn.FlatStyle = FlatStyle.Flat;
            assesmentProtocolBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolBtn.Location = new Point(1305, 3);
            assesmentProtocolBtn.Name = "assesmentProtocolBtn";
            assesmentProtocolBtn.Size = new Size(178, 49);
            assesmentProtocolBtn.TabIndex = 97;
            assesmentProtocolBtn.Text = "Оц. протокол";
            assesmentProtocolBtn.UseVisualStyleBackColor = false;
            assesmentProtocolBtn.Click += assesmentProtocolbtn_Click;
            // 
            // collectionsbtn
            // 
            collectionsbtn.BackColor = Color.NavajoWhite;
            collectionsbtn.Cursor = Cursors.Hand;
            collectionsbtn.FlatAppearance.BorderSize = 0;
            collectionsbtn.FlatStyle = FlatStyle.Flat;
            collectionsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsbtn.Location = new Point(1491, 3);
            collectionsbtn.Name = "collectionsbtn";
            collectionsbtn.Size = new Size(178, 49);
            collectionsbtn.TabIndex = 98;
            collectionsbtn.Text = "Сбирки";
            collectionsbtn.UseVisualStyleBackColor = false;
            collectionsbtn.Click += collectionsbtn_Click;
            // 
            // quieriesbtn
            // 
            quieriesbtn.BackColor = Color.NavajoWhite;
            quieriesbtn.Cursor = Cursors.Hand;
            quieriesbtn.FlatAppearance.BorderSize = 0;
            quieriesbtn.FlatStyle = FlatStyle.Flat;
            quieriesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesbtn.Location = new Point(1677, 3);
            quieriesbtn.Name = "quieriesbtn";
            quieriesbtn.Size = new Size(181, 49);
            quieriesbtn.TabIndex = 99;
            quieriesbtn.Text = "Заявки";
            quieriesbtn.UseVisualStyleBackColor = false;
            quieriesbtn.Click += queriesbtn_Click;
            // 
            // searchBtn
            // 
            searchBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(searchBtn, 2);
            searchBtn.Cursor = Cursors.Hand;
            searchBtn.FlatStyle = FlatStyle.Flat;
            searchBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            searchBtn.Location = new Point(3, 864);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(366, 37);
            searchBtn.TabIndex = 100;
            searchBtn.Text = "Търси";
            searchBtn.UseVisualStyleBackColor = false;
            searchBtn.Click += searchBtn_Click;
            // 
            // Artefacts
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(1500, 724);
            Name = "Artefacts";
            Text = "Артефакти";
            Load += Artefactscs_Load;
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)artefactsDataGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private BindingSource bindingSource1;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button updateBtn;
        private Button deleteBtn;
        private Button addNewBtn;
        private TextBox indexTxt;
        private DataGridView artefactsDataGrid;
        private ComboBox sectionsComboBox;
        private ComboBox nameOfMuseumComboBox;
        private TextBox techniqueTxt;
        private TextBox sizeTxt;
        private TextBox inscriptionOrDateTxt;
        private TextBox cipherTxt;
        private TextBox artefactNameTxt;
        private TextBox oldInventoryIdTxt;
        private TextBox conditionOfArtefactTxt;
        private TextBox amountOfArtefactTxt;
        private TextBox eraTxt;
        private TextBox madeTheScientificPassportTxt;
        private TextBox copiesMadeTxt;
        private TextBox participationInExhibitionsTxt;
        private TextBox conservationAndRestorationTxt;
        private TextBox scientificPublicationsTxt;
        private TextBox bibliographicEnquiryTxt;
        private TextBox registrationIdOfNMFTxt;
        private TextBox idOfPhotoNegativeTxt;
        private TextBox locationOfFindingTxt;
        private TextBox storageLocationTxt;
        private TextBox sellerOrDonaterTxt;
        private TextBox historicalEnquiryTxt;
        private TextBox idOfActOfAdmissionTxt;
        private TextBox marriageProtocolAndActOfLiquidationTxt;
        private ComboBox typeComboBox;
        private Label dateOfRegistrationLabel;
        private DateTimePicker dateOfRegistration;
        private Label dateOfCreationOfTheScientificPassportLabel;
        private PictureBox pictureBox;
        private OpenFileDialog openPictureFileDialog;
        private Button pictureBtn;
        private DateTimePicker dateOfAssesmentProtocol;
        private TextBox priceOfAssesmentProtocolTxt;
        private TextBox searchTxt;
        private ComboBox shapeComboBox;
        private ComboBox materialComboBox;
        private ComboBox assesmentProtocolIdComboBox;
        private TextBox identificationTxt;
        private Label dateOfAssesmentProtocolLabel;
        private ComboBox collectionscb;
        private Button resetBtn;
        private TextBox weightTxt;
        private DateTimePicker dateOfCreationOfTheScientificPassportTxt;
        private TableLayoutPanel tableLayoutPanel1;
        private Button menuBtn;
        private Button museumsBtn;
        private Button materialsBtn;
        private Button sectionsBtn;
        private Button artefactsBtn;
        private Button typesBtn;
        private Button shapesBtn;
        private Button assesmentProtocolBtn;
        private Button collectionsbtn;
        private Button quieriesbtn;
        private Button searchBtn;
    }
}