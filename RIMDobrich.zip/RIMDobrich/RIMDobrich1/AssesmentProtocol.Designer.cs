﻿namespace RIMDobrich1
{
    partial class AssesmentProtocol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AssesmentProtocol));
            updateBtn = new Button();
            deleteBtn = new Button();
            addNewBtn = new Button();
            indexTxt = new TextBox();
            assesmentProtocolDataGrid = new DataGridView();
            bindingSource1 = new BindingSource(components);
            priceOfAssesmentProtocolTxt = new TextBox();
            dateOfAssesmentProtocol = new DateTimePicker();
            assesmentProtocolBtn = new Button();
            collectionsBtn = new Button();
            museumsBtn = new Button();
            artefactsBtn = new Button();
            quieriesBtn = new Button();
            materialsBtn = new Button();
            shapesBtn = new Button();
            typesBtn = new Button();
            sectionsBtn = new Button();
            menuBtn = new Button();
            dateOfAssesmentProtocolLabel = new Label();
            resetBtn = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)assesmentProtocolDataGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // updateBtn
            // 
            updateBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            updateBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(updateBtn, 3);
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            updateBtn.Location = new Point(3, 699);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(525, 75);
            updateBtn.TabIndex = 45;
            updateBtn.Text = "Обнови";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updatebtn_Click_1;
            // 
            // deleteBtn
            // 
            deleteBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            deleteBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(deleteBtn, 3);
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            deleteBtn.Location = new Point(3, 813);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(525, 75);
            deleteBtn.TabIndex = 44;
            deleteBtn.Text = "Премахни";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deletebtn_Click_1;
            // 
            // addNewBtn
            // 
            addNewBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            addNewBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(addNewBtn, 3);
            addNewBtn.Cursor = Cursors.Hand;
            addNewBtn.FlatStyle = FlatStyle.Flat;
            addNewBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            addNewBtn.Location = new Point(3, 585);
            addNewBtn.Name = "addNewBtn";
            addNewBtn.Size = new Size(525, 75);
            addNewBtn.TabIndex = 43;
            addNewBtn.Text = "Добави";
            addNewBtn.UseVisualStyleBackColor = false;
            addNewBtn.Click += addNewbtn_Click_1;
            // 
            // indexTxt
            // 
            indexTxt.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            tableLayoutPanel1.SetColumnSpan(indexTxt, 3);
            indexTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            indexTxt.Location = new Point(3, 144);
            indexTxt.Multiline = true;
            indexTxt.Name = "indexTxt";
            indexTxt.PlaceholderText = "Индекс";
            indexTxt.Size = new Size(525, 60);
            indexTxt.TabIndex = 41;
            indexTxt.KeyDown += indexTxt_KeyDown;
            // 
            // assesmentProtocolDataGrid
            // 
            assesmentProtocolDataGrid.AllowUserToAddRows = false;
            assesmentProtocolDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            assesmentProtocolDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            assesmentProtocolDataGrid.BackgroundColor = Color.Tan;
            assesmentProtocolDataGrid.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            assesmentProtocolDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tableLayoutPanel1.SetColumnSpan(assesmentProtocolDataGrid, 7);
            assesmentProtocolDataGrid.Cursor = Cursors.PanNW;
            assesmentProtocolDataGrid.Location = new Point(561, 96);
            assesmentProtocolDataGrid.Name = "assesmentProtocolDataGrid";
            assesmentProtocolDataGrid.ReadOnly = true;
            assesmentProtocolDataGrid.RowHeadersWidth = 51;
            tableLayoutPanel1.SetRowSpan(assesmentProtocolDataGrid, 8);
            assesmentProtocolDataGrid.RowTemplate.Height = 29;
            assesmentProtocolDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            assesmentProtocolDataGrid.Size = new Size(1298, 907);
            assesmentProtocolDataGrid.TabIndex = 40;
            assesmentProtocolDataGrid.CellClick += typesDataGrid_CellClick_1;
            // 
            // priceOfAssesmentProtocolTxt
            // 
            tableLayoutPanel1.SetColumnSpan(priceOfAssesmentProtocolTxt, 3);
            priceOfAssesmentProtocolTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            priceOfAssesmentProtocolTxt.Location = new Point(3, 438);
            priceOfAssesmentProtocolTxt.Multiline = true;
            priceOfAssesmentProtocolTxt.Name = "priceOfAssesmentProtocolTxt";
            priceOfAssesmentProtocolTxt.PlaceholderText = "Сума";
            priceOfAssesmentProtocolTxt.Size = new Size(525, 60);
            priceOfAssesmentProtocolTxt.TabIndex = 52;
            priceOfAssesmentProtocolTxt.KeyDown += priceOfAssesmentProtocolTxt_KeyDown;
            // 
            // dateOfAssesmentProtocol
            // 
            dateOfAssesmentProtocol.CalendarFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            tableLayoutPanel1.SetColumnSpan(dateOfAssesmentProtocol, 3);
            dateOfAssesmentProtocol.Cursor = Cursors.IBeam;
            dateOfAssesmentProtocol.CustomFormat = "yyyy-MM-dd";
            dateOfAssesmentProtocol.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfAssesmentProtocol.Format = DateTimePickerFormat.Custom;
            dateOfAssesmentProtocol.Location = new Point(3, 324);
            dateOfAssesmentProtocol.Name = "dateOfAssesmentProtocol";
            dateOfAssesmentProtocol.Size = new Size(525, 52);
            dateOfAssesmentProtocol.TabIndex = 53;
            // 
            // assesmentProtocolBtn
            // 
            assesmentProtocolBtn.BackColor = Color.NavajoWhite;
            assesmentProtocolBtn.Cursor = Cursors.Hand;
            assesmentProtocolBtn.Enabled = false;
            assesmentProtocolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolBtn.FlatStyle = FlatStyle.Flat;
            assesmentProtocolBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolBtn.Location = new Point(1305, 3);
            assesmentProtocolBtn.Name = "assesmentProtocolBtn";
            assesmentProtocolBtn.Size = new Size(178, 49);
            assesmentProtocolBtn.TabIndex = 35;
            assesmentProtocolBtn.Text = "Оц. протокол";
            assesmentProtocolBtn.UseVisualStyleBackColor = false;
            // 
            // collectionsBtn
            // 
            collectionsBtn.BackColor = Color.NavajoWhite;
            collectionsBtn.Cursor = Cursors.Hand;
            collectionsBtn.FlatAppearance.BorderSize = 0;
            collectionsBtn.FlatStyle = FlatStyle.Flat;
            collectionsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsBtn.Location = new Point(1491, 3);
            collectionsBtn.Name = "collectionsBtn";
            collectionsBtn.Size = new Size(178, 49);
            collectionsBtn.TabIndex = 34;
            collectionsBtn.Text = "Сбирки";
            collectionsBtn.UseVisualStyleBackColor = false;
            collectionsBtn.Click += collectionsBtn_Click;
            // 
            // museumsBtn
            // 
            museumsBtn.BackColor = Color.NavajoWhite;
            museumsBtn.Cursor = Cursors.Hand;
            museumsBtn.FlatAppearance.BorderSize = 0;
            museumsBtn.FlatStyle = FlatStyle.Flat;
            museumsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            museumsBtn.Location = new Point(1119, 3);
            museumsBtn.Name = "museumsBtn";
            museumsBtn.Size = new Size(178, 49);
            museumsBtn.TabIndex = 33;
            museumsBtn.Text = "Музеи";
            museumsBtn.UseVisualStyleBackColor = false;
            museumsBtn.Click += museumsbtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Flat;
            artefactsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(189, 3);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(178, 49);
            artefactsBtn.TabIndex = 32;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // quieriesBtn
            // 
            quieriesBtn.BackColor = Color.NavajoWhite;
            quieriesBtn.Cursor = Cursors.Hand;
            quieriesBtn.FlatAppearance.BorderSize = 0;
            quieriesBtn.FlatStyle = FlatStyle.Flat;
            quieriesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesBtn.Location = new Point(1677, 3);
            quieriesBtn.Name = "quieriesBtn";
            quieriesBtn.Size = new Size(178, 49);
            quieriesBtn.TabIndex = 31;
            quieriesBtn.Text = "Заявки";
            quieriesBtn.UseVisualStyleBackColor = false;
            quieriesBtn.Click += queriesbtn_Click;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.Cursor = Cursors.Hand;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Flat;
            materialsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(933, 3);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(178, 49);
            materialsBtn.TabIndex = 30;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.Cursor = Cursors.Hand;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Flat;
            shapesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(747, 3);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(178, 49);
            shapesBtn.TabIndex = 29;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesbtn_Click;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.Cursor = Cursors.Hand;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Flat;
            typesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(561, 3);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(178, 49);
            typesBtn.TabIndex = 28;
            typesBtn.Text = "Видове артефакти";
            typesBtn.UseVisualStyleBackColor = false;
            typesBtn.Click += typesbtn_Click_1;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.Cursor = Cursors.Hand;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Flat;
            sectionsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(375, 3);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(178, 49);
            sectionsBtn.TabIndex = 2;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.Cursor = Cursors.Hand;
            menuBtn.FlatAppearance.BorderSize = 0;
            menuBtn.FlatStyle = FlatStyle.Flat;
            menuBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(3, 3);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(178, 49);
            menuBtn.TabIndex = 0;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click_1;
            // 
            // dateOfAssesmentProtocolLabel
            // 
            dateOfAssesmentProtocolLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            dateOfAssesmentProtocolLabel.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(dateOfAssesmentProtocolLabel, 3);
            dateOfAssesmentProtocolLabel.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            dateOfAssesmentProtocolLabel.Location = new Point(3, 286);
            dateOfAssesmentProtocolLabel.Name = "dateOfAssesmentProtocolLabel";
            dateOfAssesmentProtocolLabel.Size = new Size(422, 35);
            dateOfAssesmentProtocolLabel.TabIndex = 55;
            dateOfAssesmentProtocolLabel.Text = "Дата на оценителен протокол";
            // 
            // resetBtn
            // 
            resetBtn.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            resetBtn.BackColor = Color.NavajoWhite;
            tableLayoutPanel1.SetColumnSpan(resetBtn, 3);
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(3, 928);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(525, 75);
            resetBtn.TabIndex = 56;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(quieriesBtn, 9, 0);
            tableLayoutPanel1.Controls.Add(dateOfAssesmentProtocolLabel, 0, 2);
            tableLayoutPanel1.Controls.Add(deleteBtn, 0, 7);
            tableLayoutPanel1.Controls.Add(updateBtn, 0, 6);
            tableLayoutPanel1.Controls.Add(collectionsBtn, 8, 0);
            tableLayoutPanel1.Controls.Add(assesmentProtocolBtn, 7, 0);
            tableLayoutPanel1.Controls.Add(addNewBtn, 0, 5);
            tableLayoutPanel1.Controls.Add(menuBtn, 0, 0);
            tableLayoutPanel1.Controls.Add(artefactsBtn, 1, 0);
            tableLayoutPanel1.Controls.Add(museumsBtn, 6, 0);
            tableLayoutPanel1.Controls.Add(sectionsBtn, 2, 0);
            tableLayoutPanel1.Controls.Add(typesBtn, 3, 0);
            tableLayoutPanel1.Controls.Add(indexTxt, 0, 1);
            tableLayoutPanel1.Controls.Add(materialsBtn, 5, 0);
            tableLayoutPanel1.Controls.Add(shapesBtn, 4, 0);
            tableLayoutPanel1.Controls.Add(dateOfAssesmentProtocol, 0, 3);
            tableLayoutPanel1.Controls.Add(priceOfAssesmentProtocolTxt, 0, 4);
            tableLayoutPanel1.Controls.Add(resetBtn, 0, 8);
            tableLayoutPanel1.Controls.Add(assesmentProtocolDataGrid, 3, 1);
            tableLayoutPanel1.Location = new Point(12, 12);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 9;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 9.29704952F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.3378687F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.3378687F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.3378687F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.3378687F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.3378687F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.3378687F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.3378687F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 11.3378687F));
            tableLayoutPanel1.Size = new Size(1862, 1006);
            tableLayoutPanel1.TabIndex = 57;
            // 
            // AssesmentProtocol
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(1024, 724);
            Name = "AssesmentProtocol";
            Text = "Оценителен протокол";
            Load += AssesmentProtocol_Load;
            ((System.ComponentModel.ISupportInitialize)assesmentProtocolDataGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button updateBtn;
        private Button deleteBtn;
        private Button addNewBtn;
        private TextBox indexTxt;
        private DataGridView assesmentProtocolDataGrid;
        private BindingSource bindingSource1;
        private TextBox priceOfAssesmentProtocolTxt;
        private DateTimePicker dateOfAssesmentProtocol;
        private Button assesmentProtocolBtn;
        private Button collectionsBtn;
        private Button museumsBtn;
        private Button artefactsBtn;
        private Button quieriesBtn;
        private Button materialsBtn;
        private Button shapesBtn;
        private Button typesBtn;
        private Button sectionsBtn;
        private Button menuBtn;
        private Label dateOfAssesmentProtocolLabel;
        private Button resetBtn;
        private TableLayoutPanel tableLayoutPanel1;
    }
}