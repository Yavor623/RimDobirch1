﻿namespace RIMDobrich1
{
    partial class DeletingAccountProtection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            passwordCheckBox = new CheckBox();
            passwordLabel = new Label();
            passwordTextBox = new TextBox();
            deleteAccountReadyButton = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // passwordCheckBox
            // 
            passwordCheckBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            passwordCheckBox.AutoSize = true;
            passwordCheckBox.Font = new Font("Cambria", 16F, FontStyle.Regular, GraphicsUnit.Point);
            passwordCheckBox.Location = new Point(372, 325);
            passwordCheckBox.Name = "passwordCheckBox";
            passwordCheckBox.Size = new Size(222, 36);
            passwordCheckBox.TabIndex = 29;
            passwordCheckBox.Text = "Покажи парола";
            passwordCheckBox.UseVisualStyleBackColor = true;
            passwordCheckBox.CheckedChanged += passwordCheckBox_CheckedChanged;
            // 
            // passwordLabel
            // 
            passwordLabel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            passwordLabel.AutoSize = true;
            passwordLabel.Font = new Font("Cambria", 16F, FontStyle.Regular, GraphicsUnit.Point);
            passwordLabel.Location = new Point(3, 103);
            passwordLabel.Name = "passwordLabel";
            passwordLabel.Size = new Size(109, 32);
            passwordLabel.TabIndex = 28;
            passwordLabel.Text = "Парола:";
            // 
            // passwordTextBox
            // 
            passwordTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            passwordTextBox.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            passwordTextBox.Location = new Point(3, 213);
            passwordTextBox.MaxLength = 40;
            passwordTextBox.Multiline = true;
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.PasswordChar = '*';
            passwordTextBox.Size = new Size(591, 54);
            passwordTextBox.TabIndex = 27;
            // 
            // deleteAccountReadyButton
            // 
            deleteAccountReadyButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            deleteAccountReadyButton.BackColor = Color.NavajoWhite;
            deleteAccountReadyButton.FlatAppearance.BorderSize = 0;
            deleteAccountReadyButton.FlatStyle = FlatStyle.Flat;
            deleteAccountReadyButton.Font = new Font("Cambria", 16F, FontStyle.Regular, GraphicsUnit.Point);
            deleteAccountReadyButton.Location = new Point(3, 407);
            deleteAccountReadyButton.Name = "deleteAccountReadyButton";
            deleteAccountReadyButton.Size = new Size(591, 60);
            deleteAccountReadyButton.TabIndex = 30;
            deleteAccountReadyButton.Text = "Готово";
            deleteAccountReadyButton.UseVisualStyleBackColor = false;
            deleteAccountReadyButton.Click += deleteAccountReadyButton_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(passwordLabel, 0, 0);
            tableLayoutPanel1.Controls.Add(passwordTextBox, 0, 1);
            tableLayoutPanel1.Controls.Add(passwordCheckBox, 0, 2);
            tableLayoutPanel1.Controls.Add(deleteAccountReadyButton, 0, 3);
            tableLayoutPanel1.Location = new Point(202, 142);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 28.8600273F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 28.86003F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20.2020187F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 22.0779228F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(597, 470);
            tableLayoutPanel1.TabIndex = 31;
            // 
            // DeletingAccountProtection
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1013, 753);
            Controls.Add(tableLayoutPanel1);
            MaximumSize = new Size(1031, 800);
            Name = "DeletingAccountProtection";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Проверка";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private CheckBox passwordCheckBox;
        private Label passwordLabel;
        private TextBox passwordTextBox;
        private Button deleteAccountReadyButton;
        private TableLayoutPanel tableLayoutPanel1;
    }
}