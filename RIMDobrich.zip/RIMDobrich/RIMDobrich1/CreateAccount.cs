﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RIMDobrich1
{
    public partial class CreateAccount : Form
    {
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataAdapter DtA = new MySqlDataAdapter();
        MySqlDataReader sqlRd;
        DataSet DS = new DataSet();

        String server = "127.0.0.1";
        String username = "root";
        String password = "";
        String database = "rim_dobrich";

        public CreateAccount()
        {
            InitializeComponent();
        }

        private void signInLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SignInForm signInForm = new SignInForm();
            CreateAccount signUpForm = new CreateAccount();
            signInForm.Show();
            this.Hide();
            signUpForm.Close();
        }

        private void registrationButton_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";
            try
            {
                sqlConn.Open();

                int idOfMuseum = nameOfMuseumComboBox.SelectedIndex + 1;
                int privilegeInt = privilegesComboBox.SelectedIndex + 1;
                //Вмъква в таблицата materials съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.users(firstName,lastName,username,password,privilegeId,email,dateOfBirth,nameofmuseum_id) VALUES('{firstNameTextBox.Text}','{lastNameTextBox.Text}','{usernameTextBox.Text}','{passwordTextBox.Text}','{privilegeInt}','{emailTextBox.Text}','{dateOfBirth.Text}','{idOfMuseum}')";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { sqlConn.Close(); }
            SignInForm signInForm = new SignInForm();
            CreateAccount signUpForm = new CreateAccount();
            signInForm.Show();
            this.Hide();
            signUpForm.Close();

        }
        public void UploadComboBoxPrivileges() //Добавя елементите на комбобокса от таблицата nameofmuseum
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.privileges"; //Избира всичко от таблицата nameofmuseum
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                privilegesComboBox.Items.Add(reader.GetString("privilege_name")); //Добавя елементите от колоната museum_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataNameOfMuseum() //Добавя елементите на комбобокса от таблицата nameofmuseum
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.nameofmuseum"; //Избира всичко от таблицата nameofmuseum
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                nameOfMuseumComboBox.Items.Add(reader.GetString("museum_name")); //Добавя елементите от колоната museum_name в комбобокса
            }
            sqlConn.Close();
        }

        private void passwordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (passwordCheckBox.Checked)
            {
                passwordTextBox.PasswordChar = '\0';
            }
            else
            {
                passwordTextBox.PasswordChar = '*';
            }
        }

        private void directorMenuLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DirectorMenu directorMenu = new DirectorMenu();
            CreateAccount createAccount = new CreateAccount();
            directorMenu.Show();
            this.Hide();
            createAccount.Close();
        }

        private void CreateAccount_Load(object sender, EventArgs e)
        {
            UploadComboBoxDataNameOfMuseum();
            UploadComboBoxPrivileges();
        }
    }
}
